package com.renye.demo;

import android.support.multidex.MultiDexApplication;

public class RenYeApplication extends MultiDexApplication {

    //MultiDexApplication  :: 方法数越界的解决方案 https://www.cnblogs.com/chenxibobo/p/6076459.html

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
